# leilaoUC11
Repositório criado para embutir os arquivos da UC11 do curso Técnico em desnivelamento de sistema  do Senac RS 
