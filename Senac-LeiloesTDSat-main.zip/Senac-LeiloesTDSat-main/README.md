# LeilõesTDSat

## Explicação do repositorio 
Projetos desenvolvidos no curso Técnico em desenvolvimento de sistemas do Senac

## Tecnologias utilizadas 
Java <br>
Mysql<br>
HTML / CSS / JavaScript
